package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ebay {

	public static void main(String[] args) {
		
	/*  1. Goto  ebay.in
		2. Click on register link
		3. Fill the required fields(Use different locators for different elements)
		4. Click on register
	*/
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\gangadhark\\Downloads\\chromedriver_win32\\chromedriver.exe");
        WebDriver Driver = new ChromeDriver();
        
        //1. The user should be on ebay.in
        Driver.get("https://in.ebay.com/");
        
        //2. Click on register link
        
        Driver.findElement(By.xpath("//*[@id=\"gh-ug-flex\"]/a")).click();
		
	}

}
