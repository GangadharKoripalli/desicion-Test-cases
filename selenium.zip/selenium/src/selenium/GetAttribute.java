package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetAttribute {

	public static void main(String[] args) {
		
		/*1. Goto ebay.in
		2. Get all the attribute values of the register link as per the HTML design.*/
	
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\gangadhark\\Downloads\\chromedriver_win32\\chromedriver.exe");
	        WebDriver Driver = new ChromeDriver();
	        
	        Driver.get("https://in.ebay.com/");
	        String valueAttribute = driver.findElement(By.id("getA")).getAttribute("value");
			System.out.println("Attribute of value is : "+ valueAttribute);
	}

}
