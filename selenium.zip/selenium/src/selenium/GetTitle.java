package selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetTitle {

	public static void main(String[] args) {
		
		/*1. Goto Google
		2. Search for Automation Testing
		3. Click on Search button
		4. Explicit wait based on title contains
		5. Get the title should be same as search term*/
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\gangadhark\\Downloads\\chromedriver_win32\\chromedriver.exe");
        WebDriver Driver = new ChromeDriver();
        
        //The user should go to google  
        Driver.get("https://www.google.com/");
        
       // 2. Search for Automation Testing
        	
        String Search_term = "Automation Testing";
        Driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input")).sendKeys(Search_term);
       
        // 3. Click on Search button
        Driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[3]/center/input[1]")).submit();
      
       Driver.findElement(By.xpath("//*[@id=\"hdtb-msb-vis\"]/div[3]/a")).click();
       
      /* Driver.findElement(By.xpath("//*[@id=\"o9253R949bTxzM:\"]")).click();
       Driver.findElement(By.xpath("//*[@id=\"irc-ss\"]/div[2]/div[2]/div[1]/div/div[3]/span/a")).sendKeys(Keys.ENTER);
       */
       
       
       //4.Explicit wait based on title contains
       
       Driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
       
       //5. Get the title should be same as search term*/
       if(Driver.getTitle().contains(Search_term))
    	   System.out.println("Title is same");
       else
    	   System.out.println("Title is different");
       
          
	}	

}
