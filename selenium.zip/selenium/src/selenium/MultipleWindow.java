package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MultipleWindow {

	public static void main(String[] args) {
		
		
		/*1. Goto Gmail Create account URL
		2.  Click on Term of Service
		3.  Click on Privacy Policy
		4. After all the windows are opened fetch the title & all the links avialable in each of the window*/
		
		System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\gangadhark\\\\Downloads\\\\chromedriver_win32\\chromedriver.exe");
        WebDriver Driver = new ChromeDriver();
        
        //The user should gmail account site 
        Driver.get("https://www.google.com/intl/en-GB/gmail/about/#");
        
      //  1. Goto Gmail Create account URL
        
        Driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/ul[1]/li/div/div/div[1]/div/div[3]/a[1]")).click();

        //  2.  Click on Term of Service
       WebElement term= Driver.findElement(By.xpath("//*[@id=\"view_container\"]/form/div[2]/div/div[2]/div[2]/div"));
        
        term.click();
	}

}
