package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

 

public class Navigator {
	
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        /*1. Goto Rediff.com
        2. Get & print the title of the home page
        3. Click on Sign in
        4. get& Print the title of the Login page
        5. Go Back to the previous page using navige method 
        6. get the title & check if it same as home page
        7. Use forward method & get the page title & check if it same as Login page
        8. Close all the browser entities.
*/
        
        System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\gangadhark\\\\Downloads\\\\chromedriver_win32\\chromedriver.exe");
        WebDriver Driver = new ChromeDriver();
        
        // Go to rediff.com
        Driver.get("https://www.rediff.com/");
        
        //Get & print the title of the home page
       String title=Driver.getTitle();
       System.out.println("Title is "+title);
       
       //Click on Sign in
       WebElement signin=Driver.findElement(By.xpath("//*[@id=\"signin_info\"]/a[1]"));
       signin.click();
       
       //get& Print the title of the Login page
       String title1=Driver.getTitle();
       System.out.println("Title is "+title1);
       
       //Go Back to the previous page using navige method 
       Driver.navigate().back();
       
       //get the title & check if it same as home page
       String title2=Driver.getTitle();
       System.out.println("Title after navigation to back is "+title2);
       
       //Use forward method & get the page title & check if it same as Login page
       Driver.navigate().forward();
       String title3=Driver.getTitle();
       System.out.println("Title after navigation to forward is "+title3);
       
       //Close all the browser entities.
       Driver.close();  
    }
}
 
	

