package selenium;
	
import java.util.List;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Radiobutton 
{
 public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        /*
       			Example for Radio Button & Check Boxes.
			1. Goto http://destinationqa.com/aut/RadioButtons.html
			2. Select Monday Radio Button
			3. Check Yellow & Orange check box
            
            */
    
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\gangadhark\\Downloads\\chromedriver_win32\\chromedriver.exe");
        WebDriver Driver = new ChromeDriver();
        
        //The user should be on destinationqa.com
        Driver.get("http://destinationqa.com/aut/RadioButtons.html");
        
         // 2. The user should select 'Monday' from the radio button
        WebElement Ele = Driver.findElement(By.xpath("//*[@id=\"daysofweek\"]/p[1]/input"));
        //Select Select_Category = new Select(Ele);
        //Select_Category.selectByIndex(11);
        Ele.click();
        
        //3. The user should select Orange and Yellow checkbox
        WebElement red=Driver.findElement(By.name("red"));
         if(red.isSelected())
    	  red.click();
         
         WebElement orange=Driver.findElement(By.name("orange"));
         if(!orange.isSelected())
         orange.click();
         
         WebElement yellow=Driver.findElement(By.name("yellow"));
         if(!yellow.isSelected())
         yellow.click();
         
 
       
        
    } 

}


