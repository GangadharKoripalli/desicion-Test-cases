package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectAndList {

	public static void main(String[] args) {
	
		/*  1. Goto Newtours --> http://newtours.demoaut.com/
			2. Enter Login Credential of Username & Password as "mercury"
			3. Click on Signin Button
			4. Select the passengers count as "4" using select object by index
			5. Select Departure location, Month & Date using select by Value
			6. Select Arrival location, Month,& Date  using select by Visible Text
			7. Click on Continue booking the flight ticket.*/
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\gangadhark\\Downloads\\chromedriver_win32\\chromedriver.exe");
        WebDriver Driver = new ChromeDriver();
        
        //1. The user should be on newtours.demoaut.com
        Driver.get("http://newtours.demoaut.com/");
        
  
        // 2. Enter Login Credential of Username & Password as "mercury"
        Driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[2]/td[3]/form/table/tbody/tr[4]/td/table/tbody/tr[2]/td[2]/input")).sendKeys("mercury");
       Driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[2]/td[3]/form/table/tbody/tr[4]/td/table/tbody/tr[3]/td[2]/input")).sendKeys("mercury");
           
       // 3. Click on Signin Button
       Driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[2]/td[3]/form/table/tbody/tr[4]/td/table/tbody/tr[4]/td[2]/div/input")).click();
	
	 // 4. Select the passengers count as "4" using select object by index
       
       WebElement Ele = Driver.findElement(By.xpath(" /html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[3]/td[2]/b/select"));
       Select Select_Category = new Select(Ele);
       Select_Category.selectByIndex(3);
       
      // 5. Select Departure location, Month & Date using select by Value
      
      WebElement dep=Driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[4]/td[2]/select/option[7]"));
      dep.click();
//      Select bv = new Select(val);
//      bv.selectByValue("val");
      WebElement mon=Driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[5]/td[2]/select[1]/option[3]"));
      mon.click();
      
      WebElement da=Driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[5]/td[2]/select[2]/option[16]"));
      da.click();
      
      WebElement Arrival=Driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[6]/td[2]/select/option[3]"));
      Arrival.click();
      
      WebElement Mon=Driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[7]/td[2]/select[1]/option[12]"));
     Mon.click();
      
      WebElement date=Driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[7]/td[2]/select[2]/option[10]"));
      date.click();
      
      Driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[14]/td/input")).click();
	}

}
